import React, {Component} from 'react';
import styled from 'styled-components';
import {Row, Column, Colors, H1, H2, H3, InnerWrapper, PrimaryButton, SecondaryButton, IconButton,} from '../Theme';

class Styleguide extends Component {
    render() {
        return (
            <InnerWrapper>
                <H1>Colors</H1>
                <Row grid columns={"repeat(5,1fr)"}>
                    <BaseBlackColor>
                        <p>Base UI Black</p>
                        <p>{Colors.font_color}</p>
                    </BaseBlackColor>
                    <PrimaryColor>
                        <p>Primary Band Color</p>
                        <p>{Colors.primary_color}</p>
                    </PrimaryColor>
                    <SecondaryColor>
                        <p>Secondary/ Hint Text</p>
                        <p>{Colors.secondary_color}</p>
                    </SecondaryColor>
                    <SuccessColor>
                        <p>Success</p>
                        <p>{Colors.success_color}</p>
                    </SuccessColor>
                    <WarningColor>
                        <p>Warning/ Error/ Sale</p>
                        <p>{Colors.error_color}</p>
                    </WarningColor>
                </Row>
                <H1>Buttons</H1>
                <Row grid columns={"repeat(4,1fr)"}>
                    <Column><PrimaryButton>Primary</PrimaryButton></Column>
                    <Column><SecondaryButton>Secondary</SecondaryButton></Column>
                    <Column><IconButton>Icon Button</IconButton></Column>
                </Row>
                <H1>Typography</H1>
                <Row grid columns={"repeat(1,1fr)"}>
                    <Column><H1>Title One</H1></Column>
                    <Column><H2>Title Two</H2></Column>
                    <Column><H3>Title Three</H3></Column>
                    <P></P>
                    <Column><a href="#">Primary Text Links</a></Column>
                </Row>
            </InnerWrapper>
        );
    }
}

const Color = styled(Column)`
  text-align: center;
`;

const BaseBlackColor = styled(Color)`
  background-color: ${Colors.black};
`;

const PrimaryColor = styled(Color)`
  background-color: ${Colors.primary_color};
`;

const SecondaryColor = styled(Color)`
  background-color: ${Colors.secondary_color};
`;

const SuccessColor = styled(Color)`
  background-color: ${Colors.success_color};
`;

const WarningColor = styled(Color)`
  background-color: ${Colors.error_color};
`;

export default Styleguide;